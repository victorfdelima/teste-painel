@extends('admin.layout.base')

@section('title', 'Ajuda ')

@section('content')

    <div class="content-area py-1">
        <div class="container-fluid">
            <div class="box box-block bg-white">
                Gostaríamos de agradecer por decidir usar nosso script. Nós gostamos de criá-lo e esperamos que você goste de usá-lo para alcançar seus objetivos :) Se você quiser algo melhor para melhor atender às necessidades do seu empreendimento, entre em contato conosco: contato@programmerweb.com.br
            </div>
        </div>
    </div>

@endsection
